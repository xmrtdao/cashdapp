# Grant Opportunities for XMRT & Suite

## 1. Aleo Ecosystem Grants (High Priority)

* **Focus:** Privacy-preserving applications, ZK tools, Open Source.
* **Requirements:**
  * Team Information (GitHub, Discord, Aleo Wallet).
  * Detailed Proposal (Problem, Solution, Tech Architecture, Budget, Milestones). -> **Draft Available (`XMRT_Aleo_Grant_Proposal.md`)**
  * Working Demo / MVP.
* **Action:** Finalize existing proposal, fill placeholders, submit via Aleo application portal.

## 2. Monero Community Crowdfunding System (CCS)

* **Focus:** Monero ecosystem improvements, research, and adoption.
* **Requirements:**
  * GitLab Merge Request to `monero-project/ccs-proposals`.
  * Strict structure: Proposal, Milestones, Timeline.
  * Community consensus required.
* **Relevance:** XMRT is built on Monero (mobile mining, banking). A proposal to fund the "Mobile Mining Optimization" or "Monero-Aleo Bridge" would be strong.
* **Action:** Draft CCS Proposal MD file based on `xmrt-whitepaper.md`.

## 3. DePIN & Web3 Privacy Grants

### Peaq DePIN Grant

* **Focus:** Decentralized Physical Infrastructure Networks (DePIN), Layer-2, Machine DeFi.
* **Relevance:** XMRT's "Mobile Mining Mesh" fits the DePIN narrative perfectly.

### Disrupt.Build

* **Focus:** Infrastructure ($100k) & Hardware ($50k).
* **Requirements:** Open source, MVP, Tech Docs.

### Aztec & Oasis

* **Focus:** Privacy layer 2s.
* **Relevance:** Potential for cross-chain privacy partnerships (XMRT <-> Aztec).

## 4. AI & Research Grants

### Google Research (AI for Privacy/Safety)

* **Focus:** Academic/Research institutions mostly, but beneficial to look into for the "AI Governance" aspect.

### Openfabric

* **Focus:** Decentralized AI, Security & Privacy in AI.
* **Relevance:** Matches "Suite" (AI Automation) goals.

## 5. Other Potential Sources

* **Gitcoin Grants:** Public goods funding (if XMRT components are open sourced).
* **Optimism RetroPGF:** If we deploy on Optimism/Superchain.
