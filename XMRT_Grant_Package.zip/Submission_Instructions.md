# Master Grant Submission Guide

Use this checklist to submit your 8 grant applications.

## 1. Aleo Ecosystem Grant

* **Method:** Web Form
* **URL:** <https://aleo.org/grants> (or <https://applications.aleo.org>)
* **Action:**
    1. Go to URL.
    2. Fill in Team Details.
    3. **Upload/Paste:** Content from `XMRT_Aleo_Grant_Proposal.md`.
    4. **Submit.**

## 2. Monero CCS

* **Method:** GitLab Merge Request
* **URL:** <https://gitlab.com/monero-project/ccs-proposals>
* **Action:**
    1. Fork the repo.
    2. Create a file `xmrt-mobile-mining.md` in the `proposals` folder.
    3. **Paste:** Content from `Monero_CCS_Proposal.md`.
    4. Submit Merge Request.

## 3. Peaq Ecosystem Grant

* **Method:** Email or Web Form
* **URL:** <https://www.peaq.network/grant-program>
* **Email:** <grants@peaq.network>
* **Action:**
  * **Send Email** using Template #1 (General) or the Web Form.
  * **Attach:** `Peaq_Grant_Proposal.md`.

## 4. Phala Network Builders Program

* **Method:** Web Form / Forum
* **URL:** <https://phala.network/build>
* **Action:**
  * Apply via "Builders Program" link.
  * **Attach:** `Phala_Grant_Proposal.md`.

## 5. NEAR AI Agent Fund

* **Method:** Web Application
* **URL:** <https://near.org/ai>
* **Action:**
  * Look for "AI Fund" or "Grants".
  * **Attach:** `Near_AI_Agent_Proposal.md`.

## 6. Akash Network

* **Method:** Community Forum / GitHub
* **URL:** <https://github.com/akash-network/community/tree/main/steering-committee>
* **Action:**
  * Create a generic issue or post on the [Akash Forum](https://forum.akash.network).
  * **Copy/Paste:** `Akash_Grant_Proposal.md`.

## 7. Filecoin Open Grants

* **Method:** GitHub Pull Request
* **URL:** <https://github.com/filecoin-project/devgrants>
* **Action:**
  * Fork repo.
  * Create new proposal file.
  * **Paste:** `Filecoin_Grant_Proposal.md`.
  * Submit PR.

## 8. DFINITY / ICP Developer Grant

* **Method:** Submittable Form
* **URL:** <https://dfinity.org/grants>
* **Action:**
  * Click "Apply for Grant".
  * Select "DeAI" track if available.
  * **Attach:** `ICP_Grant_Proposal.md`.
