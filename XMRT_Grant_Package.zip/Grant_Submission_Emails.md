# Grant Submission Email Templates

## 1. General Submission Email

**Subject:** Grant Application: XMRT - Privacy-First Mobile DePIN & AI Banking

**Body:**

Dear Grants Committee,

Please find attached our proposal for the [Name of Grant Program].

**Project Name:** XMRT (XMR Trust)
**Category:** DePIN / Privacy / AI
**One-Line Pitch:** A mobile-first DePIN that aggregates smartphone computing power for privacy-preserving mining and AI automation.

**Why it fits [Ecosystem Name]:**
[Customize this sentence based on the ecosystem, e.g., "XMRT leverages Peaq IDs for device verification..." or "XMRT uses Phala TEEs for confidential AI..."]

We believe XMRT can bring thousands of active mobile users and a real-world utility (mining/compute) to your ecosystem.

Attached Documents:

1. Full Grant Proposal (PDF/Markdown)
2. Technical Whitepaper
3. Team Background

We are happy to jump on a call to demonstrate our "Suite" beta and discuss how we can align with your roadmap.

Best regards,

The XMRT Development Team
<xmrtnet@gmail.com>
suite-beta.vercel.app

---

## 2. Phala Network Specific

**Subject:** Builders Program Application: XMRT Confidential AI Agents

**Body:**

Hi Phala Team,

We are excited to submit XMRT for the Phala Builders Program.

We are building "Suite," an AI automation platform for crypto natives. We want to move our AI Agent logic (currently centralized) into **Phat Contracts** to ensure verifiable privacy for our users' financial strategies.

Our proposal outlines how we will use Phala TEEs to secure our "Mobile Mining Mesh" and enable confidential DeFi automation.

**Proposal Link / Attachment:** [Attach Phala_Grant_Proposal.md]

Looking forward to building on the Phala stack!

Best,
XMRT Team

---

## 3. NEAR Foundation Specific

**Subject:** AI Agent Fund Proposal: XMRT Autonomous Mining Agents

**Body:**

To the NEAR Foundation / AI Team,

We are building autonomous AI agents that *earn*—specifically by managing decentralized physical infrastructure (mining rigs and mobile devices).

We propose using **NEAR Chain Signatures** and **Intents** to give these agents true autonomy, allowing them to manage cross-chain assets (Monero, Bitcoin) directly from a NEAR account.

Attached is our proposal for the AI Agent Fund. We believe XMRT can be a flagship example of "User-Owned AI" on NEAR.

Best,
XMRT Team
