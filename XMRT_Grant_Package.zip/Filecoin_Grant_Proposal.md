# XMRT Archive: Permanent Ledger History

## Filecoin Open Grant Proposal

---

## 1. Project Overview

**Project Name:** XMRT Ledger Archive
**Category:** Storage / Developer Tools
**Target:** Filecoin Foundation Open Grant

## 2. The Problem

Mobile devices have limited storage (64GB-256GB). They cannot store the full XMRT/Monero blockchain history (100GB+). Mobile wallets must rely on "Remote Nodes," which are centralized and create a single point of failure (and trust).

## 3. The Solution: Filecoin Snapshots

We will build a system to periodically snapshot the XMRT blockchain and store it immutably on **Filecoin/IPFS**.

* **Bootstrap from IPFS:** New mobile nodes can download the latest "checkpoint" from IPFS at high speed, verifying it against the Filecoin consensus, rather than syncing slowly from peers.
* **Decentralized Archival:** The entire transaction history is preserved permanently ensuring the "Right to Exit" and "Right to Audt" even if the main XMRT nodes go offline.

## 4. Technical Approach

1. **Snapshot Service:** A script running on a full node that creates daily `bootstrap.dat` files.
2. **Lotus Integration:** These files are packaged (CAR format) and dealt to Filecoin Storage Providers.
3. **Mobile Retrieval:** The XMRT App includes a lightweight IPFS client to fetch the latest snapshot during the first-time setup ("Fast Sync").

## 5. Funding Request ($10,000)

* **Dev Work:** Building the automated snapshot-to-Filecoin pipeline.
* **Storage Costs:** Subsidizing the initial storage deals.
* **Mobile Integration:** Adding IPFS fetch logic to the Android app.

## 6. Impact

This enables a true "Light Client" experience for mobile users, removing the #1 barrier to running a full self-sovereign bank on a phone: synchronziation time.
